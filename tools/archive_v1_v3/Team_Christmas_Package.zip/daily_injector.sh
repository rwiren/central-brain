#!/bin/bash

# --- CONFIGURATION ---
WORK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PYTHON_EXEC="/Users/riku/.pyenv/shims/python3"
DB_NAME="readsb"
LOG_FILE="$WORK_DIR/daily_log.txt"

# --- SMART STORAGE DETECTION ---
echo "--- Starting Daily Pipeline: $(date) ---" > "$LOG_FILE" # Start fresh log
echo "🔍 Detecting Cloud Storage..." | tee -a "$LOG_FILE"

# 1. Try to find Google Drive in CloudStorage (Modern macOS)
GDRIVE_PATH=$(find "$HOME/Library/CloudStorage" -maxdepth 1 -name "GoogleDrive*" -type d 2>/dev/null | head -n 1)

# 2. If not found, try /Volumes (Legacy/Streaming Mode)
if [ -z "$GDRIVE_PATH" ]; then
    GDRIVE_PATH=$(find "/Volumes" -maxdepth 1 -name "GoogleDrive*" -type d 2>/dev/null | head -n 1)
fi

# 3. Configure the Output
if [ -n "$GDRIVE_PATH" ]; then
    # Google Drive Found!
    # Try "My Drive" first, fallback to root if missing
    if [ -d "$GDRIVE_PATH/My Drive" ]; then
        STORAGE_DIR="$GDRIVE_PATH/My Drive/Platinum_Data_Stream"
    else
        STORAGE_DIR="$GDRIVE_PATH/Platinum_Data_Stream"
    fi
    echo "✅ Target: Google Drive ($STORAGE_DIR)" | tee -a "$LOG_FILE"
else
    # Google Drive Missing -> Fallback to Local Storage
    echo "⚠️ Google Drive NOT FOUND. Is the app running?" | tee -a "$LOG_FILE"
    echo "⚠️ Falling back to local storage." | tee -a "$LOG_FILE"
    STORAGE_DIR="$WORK_DIR/platinum_storage"
fi

# Create the directory if it doesn't exist
mkdir -p "$STORAGE_DIR"
cd "$WORK_DIR" || exit 1

# --- EXECUTION ---
{
    TODAY=$(date +%Y-%m-%d)
    PREFIX="raw_dump_$TODAY"
    PARQUET_ENRICHED="${PREFIX}_enriched.parquet"
    PARQUET_PLATINUM="${PREFIX}_platinum.parquet"

    # Step 1: Extract
    echo "[1/4] Dumping Data..."
    "$PYTHON_EXEC" dump_raw_campaign.py --db "$DB_NAME" "$PREFIX"

    # Step 2: Enrich
    echo "[2/4] Converting to Enriched..."
    if [ -f "${PREFIX}_local_aircraft_state.json" ]; then
        "$PYTHON_EXEC" convert_to_enriched.py "$PREFIX"
    else
        echo "❌ Dump failed."
        exit 1
    fi

    # Step 3: Refine
    echo "[3/4] Generating Platinum..."
    "$PYTHON_EXEC" process_dataset_platinum_v2.py "$PARQUET_ENRICHED"

    # Step 4: Publish
    if [ -f "$PARQUET_PLATINUM" ]; then
        echo "[4/4] Syncing File..."
        mv "$PARQUET_PLATINUM" "$STORAGE_DIR/"
        
        # Cleanup
        rm "${PREFIX}"_*.json 2>/dev/null
        rm "$PARQUET_ENRICHED" 2>/dev/null
        
        echo "✅ SUCCESS: Saved to $STORAGE_DIR"
    else
        echo "❌ Platinum generation failed."
    fi

    echo "----------------------------------------"
    
} 2>&1 | tee -a "$LOG_FILE"
