#!/usr/bin/env python3
"""
Script: dump_raw_campaign.py
Description: Extracts aircraft state and environmental data from InfluxDB 
             to local JSON lines files.
Author: Riku (Archive Refactoring)
Version: 1.2.0
Last Updated: 2025-12-24

Changelog:
v1.1.0 - JSONL output, iteration fix.
v1.2.0 - ADDED: Database discovery (lists DBs if target not found).
       - ADDED: CLI Argument parsing for db name and output file.
       - FIXED: Connection handling logic.
"""

import sys
import json
import time
import argparse
import struct
from datetime import datetime, timedelta
from influxdb import InfluxDBClient
from influxdb.exceptions import InfluxDBClientError

# --- Defaults ---
DEFAULT_HOST = '192.168.1.134'
DEFAULT_PORT = 8086
DEFAULT_DB = 'campaign_data' 
TARGET_TABLES = [
    'local_aircraft_state',
    'global_aircraft_state',
    'weather_local',
    'physics_alerts'
]

def parse_args():
    parser = argparse.ArgumentParser(description="Dump InfluxDB tables to JSONL.")
    parser.add_argument('output_file', nargs='?', help="Optional output filename prefix (e.g., raw_dump.json)")
    parser.add_argument('--db', type=str, default=DEFAULT_DB, help=f"Target Database name (default: {DEFAULT_DB})")
    parser.add_argument('--host', type=str, default=DEFAULT_HOST, help="InfluxDB Host IP")
    return parser.parse_args()

def get_time_window():
    """
    Calculates the 6-hour lookback window based on current execution time.
    """
    now = datetime.utcnow()
    start_time = now - timedelta(hours=6)
    return start_time, now

def check_database_exists(client, target_db):
    """
    Checks if DB exists. If not, prints available DBs to help user debug.
    """
    try:
        # Get list of dictionaries: [{'name': 'telegraf'}, {'name': '_internal'}]
        db_list = client.get_list_database()
        existing_names = [d['name'] for d in db_list]
        
        if target_db in existing_names:
            return True
        
        print(f"❌ ERROR: Database '{target_db}' not found.")
        print("   Available databases on server:")
        for name in existing_names:
            print(f"    - {name}")
        return False
        
    except Exception as e:
        print(f"❌ ERROR: Could not list databases. Connection failed? Details: {e}")
        return False

def dump_table(client, table_name, start_dt, end_dt, file_prefix):
    """
    Queries specific table and dumps to JSONL.
    """
    print(f"   > Dumping table: {table_name}...", end=" ", flush=True)
    
    # Determine filename: use prefix if provided, else standard timestamp naming
    if file_prefix:
        # If user gave "dump.lp", we rename to "dump_tablename.json" to keep format correct
        clean_prefix = file_prefix.rsplit('.', 1)[0]
        filename = f"{clean_prefix}_{table_name}.json"
    else:
        filename = f"{table_name}_{int(time.time())}.json"
    
    query = f"SELECT * FROM \"{table_name}\" WHERE time >= '{start_dt.isoformat()}Z' AND time <= '{end_dt.isoformat()}Z'"
    
    try:
        result = client.query(query, epoch='ms')
        points = list(result.get_points())
        
        if not points:
            print("Skipped (No data points in window).")
            return

        with open(filename, 'w') as f:
            for point in points:
                f.write(json.dumps(point) + '\n')
                
        print(f"Success ({len(points)} records -> {filename})")

    except InfluxDBClientError as e:
        print(f"Error: InfluxDB Query Error - {e}")
    except struct.error as e:
        print(f"Error: Binary Unpack Error (msgpack issue) - {e}")
    except Exception as e:
        print(f"Error: {e}")

def main():
    args = parse_args()
    
    print(f"[INFO] Connecting to {args.host}...")
    
    # Connect without selecting a DB first to verify connection and list DBs
    client = InfluxDBClient(host=args.host, port=DEFAULT_PORT)
    
    # Verify Connection
    try:
        client.ping()
    except Exception as e:
        print(f"❌ CRITICAL: Could not reach InfluxDB at {args.host}. Is VPN/Network up?")
        sys.exit(1)

    # Verify Database Name
    if not check_database_exists(client, args.db):
        print("\n[ACTION REQUIRED] Please rerun with the correct --db argument.")
        sys.exit(1)
        
    # Switch to the verified database
    client.switch_database(args.db)

    start_window, end_window = get_time_window()
    print(f"[INFO] Target Window: {start_window.isoformat()}Z to {end_window.isoformat()}Z")
    print(f"[INFO] Source DB: {args.db}")

    for table in TARGET_TABLES:
        dump_table(client, table, start_window, end_window, args.output_file)

    print("\n[INFO] Extraction process completed.")

if __name__ == "__main__":
    main()
