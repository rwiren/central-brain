#!/usr/bin/env python3
"""
Script: convert_to_enriched.py
Description: Merges JSONL dumps into a single time-indexed Parquet file.
             - Handles data gaps by creating 'segment_ids'.
             - Forward-fills low-frequency global/weather data.
             - Enriches with derived physics columns.
Author: Riku (Archive Refactoring)
Version: 1.0.0
"""

import sys
import json
import pandas as pd
import numpy as np
from datetime import datetime

# Configuration
GAP_THRESHOLD_SEC = 30.0  # Split segment if gap > 30s
OUTPUT_SUFFIX = "_enriched.parquet"

def load_jsonl(filepath, time_col='time'):
    """Loads JSONL into a Pandas DataFrame and handles timestamps."""
    print(f"   Reading {filepath}...", end=" ", flush=True)
    try:
        data = []
        with open(filepath, 'r') as f:
            for line in f:
                data.append(json.loads(line))
        
        df = pd.DataFrame(data)
        
        # Convert time to datetime objects (UTC)
        # InfluxDB often returns epoch ms (int) or ISO string
        if df[time_col].dtype == object:
            # Assume string ISO
            df[time_col] = pd.to_datetime(df[time_col])
        else:
            # Assume epoch milliseconds
            df[time_col] = pd.to_datetime(df[time_col], unit='ms')
            
        print(f"Loaded {len(df)} rows.")
        return df
    except Exception as e:
        print(f"Failed: {e}")
        return pd.DataFrame()

def process_data(prefix):
    # 1. Load DataFrames
    df_local = load_jsonl(f"{prefix}_local_aircraft_state.json")
    df_global = load_jsonl(f"{prefix}_global_aircraft_state.json")
    df_weather = load_jsonl(f"{prefix}_weather_local.json")
    
    if df_local.empty:
        print("❌ Error: No local aircraft state data found. Aborting.")
        return

    # 2. Sort and Index by Time
    df_local = df_local.sort_values('time').reset_index(drop=True)
    
    # 3. Handle Gaps (The 37min blackout fix)
    print("   Processing time gaps and segments...", end=" ")
    # Calculate time difference between rows in seconds
    df_local['dt'] = df_local['time'].diff().dt.total_seconds().fillna(0)
    
    # Create a new segment ID every time the gap exceeds threshold
    df_local['gap_flag'] = (df_local['dt'] > GAP_THRESHOLD_SEC).astype(int)
    df_local['segment_id'] = df_local['gap_flag'].cumsum()
    print(f"Created {df_local['segment_id'].max() + 1} distinct segments.")

    # 4. Merge Global State (As-of merge / Forward fill)
    # We want the most recent global state for every local timestamp
    print("   Merging Global and Weather data...", end=" ")
    
    df_global = df_global.sort_values('time')
    df_weather = df_weather.sort_values('time')
    
    # Use merge_asof for efficient nearest-prior-neighbor lookup
    df_merged = pd.merge_asof(
        df_local, 
        df_global, 
        on='time', 
        direction='backward', 
        suffixes=('', '_global')
    )
    
    df_merged = pd.merge_asof(
        df_merged, 
        df_weather, 
        on='time', 
        direction='backward', 
        suffixes=('', '_weather')
    )
    print("Done.")

    # 5. Clean up columns
    # Drop internal helper columns if needed, but keep segment_id
    cols_to_drop = ['gap_flag', 'dt']
    df_merged = df_merged.drop(columns=cols_to_drop, errors='ignore')

    # 6. Save to Parquet
    output_file = f"{prefix}{OUTPUT_SUFFIX}"
    print(f"   Saving to {output_file}...", end=" ")
    df_merged.to_parquet(output_file, index=False)
    print("Success!")

def main():
    if len(sys.argv) < 2:
        print("Usage: python3 convert_to_enriched.py <file_prefix>")
        sys.exit(1)
        
    prefix = sys.argv[1]
    
    print(f"[INFO] Processing dataset: {prefix}")
    process_data(prefix)

if __name__ == "__main__":
    main()
