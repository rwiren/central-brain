#!/usr/bin/env python3
"""
System: Central Brain - Data Refinery (Platinum v3.2)
Description: Ingests Enriched Parquet, performs Sensor Fusion, 
             and calculates Physics/Context features.
Input:  *_enriched.parquet
Output: *_platinum.parquet
"""

import sys
import pandas as pd
import numpy as np

# --- CONFIG ---
EFHK_LAT = 60.3172
EFHK_LON = 24.9633

def haversine_vectorized(lon1, lat1, lon2, lat2):
    """Calculate KM distance between vectors of coordinates"""
    # Convert decimal degrees to radians 
    lon1, lat1, lon2, lat2 = map(np.radians, [lon1, lat1, lon2, lat2])

    # Haversine formula 
    dlon = lon2 - lon1 
    dlat = lat2 - lat1 
    a = np.sin(dlat/2)**2 + np.cos(lat1) * np.cos(lat2) * np.sin(dlon/2)**2
    c = 2 * np.arcsin(np.sqrt(a)) 
    r = 6371 # Radius of earth in kilometers
    return c * r

def process_parquet(filename):
    print(f"[1/4] Loading {filename}...")
    df = pd.read_parquet(filename)
    
    # Ensure time is standard
    df['time'] = pd.to_datetime(df['time'])
    
    # Create a rounded second key for fusion alignment
    df['time_sec'] = df['time'].dt.round('1s')

    # --- SENSOR FUSION ---
    print(f"[2/4] Fusing Sensors (Office vs Balcony)...")
    
    # Split by host
    # Note: If you only have one host (office), the balcony columns will just be NaNs, which is fine.
    df_office = df[df['host'] == 'keimola-office'].copy()
    df_balcony = df[df['host'] == 'keimola-balcony'].copy()
    
    # We index by (time_sec, icao24) to align the two sensors
    # We drop duplicates to prevent explosion if multiple packets arrived in the same second
    df_office = df_office.drop_duplicates(subset=['time_sec', 'icao24'])
    df_balcony = df_balcony.drop_duplicates(subset=['time_sec', 'icao24'])
    
    df_office = df_office.set_index(['time_sec', 'icao24'])
    df_balcony = df_balcony.set_index(['time_sec', 'icao24'])

    # Rename balcony columns to avoid collision, we only really care about RSSI from balcony for comparison
    df_balcony = df_balcony[['rssi']].rename(columns={'rssi': 'rssi_balcony'})

    # Master Merge (Left join: We care about Office data primarily)
    # The 'enriched' file already contains the Global/Weather data columns.
    merged = df_office.join(df_balcony, how='left')
    
    # Rename office RSSI for clarity
    merged = merged.rename(columns={'rssi': 'rssi_office'})
    
    # Calculate Signal Delta (Interference detection)
    merged['rssi_delta'] = merged['rssi_office'] - merged['rssi_balcony']

    # --- PHYSICS & CONTEXT ---
    print(f"[3/4] Calculating Physics & Truth Deltas...")
    
    # 1. Error Distance (Accuracy against Global Truth)
    # The enriched file has 'lat_global' and 'lon_global'. 
    # If they are NaN (no global match), result is NaN.
    if 'lat_global' in merged.columns:
        merged['error_dist_km'] = haversine_vectorized(
            merged['lon'], merged['lat'],
            merged['lon_global'], merged['lat_global']
        )
    else:
        merged['error_dist_km'] = np.nan

    # 2. Airport Proximity (Context for AI)
    merged['dist_to_efhk_km'] = haversine_vectorized(
        merged['lon'], merged['lat'],
        np.full(len(merged), EFHK_LON), np.full(len(merged), EFHK_LAT)
    )

    # --- EXPORT ---
    print(f"[4/4] Saving Platinum Dataset...")
    
    # Reset index to make time and icao columns again
    final = merged.reset_index()
    
    # Clean up filename
    output_file = filename.replace('_enriched.parquet', '_platinum.parquet')
    
    # Convert object cols to string for Parquet compatibility
    for c in final.columns:
        if final[c].dtype == 'object':
            final[c] = final[c].astype(str)

    final.to_parquet(output_file)
    print(f"✅ DONE: {output_file}")
    print(f"   > Records: {len(final)}")
    print(f"   > Features added: rssi_delta, error_dist_km, dist_to_efhk_km")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python3 process_dataset_platinum_v2.py <file_enriched.parquet>")
        sys.exit(1)
        
    process_parquet(sys.argv[1])
